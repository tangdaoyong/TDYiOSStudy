//
//  main.m
//  SMS_SDKDemo
//
//  Created by 掌淘科技 on 14-8-28.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "YJAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([YJAppDelegate class]));
    }
}
